<?php
session_start();

$name = $_POST['fullName'];
$subject = $_POST['subject'];

?>
<div id="main-content">

</div>